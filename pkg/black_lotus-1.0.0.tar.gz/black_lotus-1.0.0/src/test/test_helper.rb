require "test/unit"

require "black_lotus"
